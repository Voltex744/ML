# Practical 4: Polynomial Regression
# Dataset: Diabetes dataset (from sklearn, originally from Efron et al.)
# Goal: Fit a curve (degree 2) between BMI and disease progression

import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error, r2_score

# Step 1: Load the dataset
data = load_diabetes()
X = data.data[:, [2]]   # BMI feature
y = data.target

# Step 2: Split into training set (80%) and test set (20%)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 3: Create model = Polynomial features (x, x^2) + Linear Regression
degree = 2
model = make_pipeline(PolynomialFeatures(degree), LinearRegression())
model.fit(X_train, y_train)

# Step 4: Predict on the test set
y_pred = model.predict(X_test)

# Step 5: Evaluation
print("===== Polynomial Regression (degree", degree, ") =====")
print("MSE      :", round(mean_squared_error(y_test, y_pred), 4))
print("R2 Score :", round(r2_score(y_test, y_pred), 4))

# Step 6: K-fold cross-validation (k = 5)
r2_scores = cross_val_score(model, X, y, cv=5, scoring="r2")
mse_scores = -cross_val_score(model, X, y, cv=5, scoring="neg_mean_squared_error")
print("\n5-Fold CV R2  :", r2_scores.round(4), " Mean:", round(r2_scores.mean(), 4))
print("5-Fold CV MSE :", mse_scores.round(2), " Mean:", round(mse_scores.mean(), 4))

# Step 7: Plot the curve
x_line = np.linspace(X.min(), X.max(), 100).reshape(-1, 1)
plt.scatter(X_test, y_test, color="blue", label="Actual")
plt.plot(x_line, model.predict(x_line), color="red", label="Polynomial curve")
plt.xlabel("BMI")
plt.ylabel("Disease progression")
plt.title("Polynomial Regression")
plt.legend()
plt.show()


# =====================================================================
#                    THEORY AND EXPLANATION
# =====================================================================
'''
1. WHAT IS POLYNOMIAL REGRESSION?
---------------------------------
When the relation between x and y is CURVED (not a straight line),
we fit a polynomial curve instead of a line.

  Equation (degree n):
    y = b0 + b1*x + b2*x^2 + b3*x^3 + ... + bn*x^n

  For degree 2 (used here):  y = b0 + b1*x + b2*x^2   (a parabola)

2. WHY IS IT STILL CALLED "LINEAR" REGRESSION?
----------------------------------------------
The curve is not linear in x, but it is LINEAR IN THE COEFFICIENTS
(b0, b1, b2). So we can create new features x, x^2, x^3 ... and then
use ordinary Linear Regression on these new features.

  Original feature:   x
  New features:       [1, x, x^2]          (PolynomialFeatures(degree=2))

3. CHOOSING THE DEGREE: UNDERFITTING VS OVERFITTING
---------------------------------------------------
  - Degree too LOW  -> UNDERFITTING: model is too simple, cannot capture
                       the pattern. High error on both training and test data.
                       (High bias)
  - Degree too HIGH -> OVERFITTING: curve wiggles to pass through every
                       training point, including noise. Low training error
                       but high test error. (High variance)
  - Best degree     -> lowest error on test data / cross-validation.

  This is called the BIAS-VARIANCE TRADE-OFF.
  Try changing "degree = 2" to 1, 3, 5, 10 and compare the R2 values.

4. HOW THE PROGRAM WORKS
------------------------
  a) Load Diabetes dataset, use only BMI as input.
  b) Split 80% training, 20% testing.
  c) make_pipeline(PolynomialFeatures(2), LinearRegression()):
       Step 1 -> converts x into [1, x, x^2]
       Step 2 -> fits linear regression on these features
     A pipeline joins steps so they run one after another automatically.
  d) Predict on test set, calculate MSE and R2.
  e) 5-fold cross-validation (the pipeline is re-run inside each fold).
  f) Plot the curve using 100 evenly spaced x values (np.linspace).

  Result: degree 2 gives almost the same R2 as simple linear regression,
  which tells us the BMI - disease relation is already nearly a straight
  line. Polynomial regression helps only when the data is truly curved.

5. EVALUATION METRICS AND FORMULAS
----------------------------------
  MSE = (1/n) * sum of (yi - yi_pred)^2          -> lower is better
  R2  = 1 - SS_res / SS_tot
      = 1 - [ sum (yi - yi_pred)^2 / sum (yi - y_mean)^2 ]  -> closer to 1 is better

6. TRAIN-TEST SPLIT AND K-FOLD CROSS-VALIDATION
-----------------------------------------------
  Cross-validation is very useful here for CHOOSING THE DEGREE:
  try several degrees and pick the one with the best mean CV score.

7. ADVANTAGES AND DISADVANTAGES
-------------------------------
  Advantages: can model curved relationships, still simple to train.
  Disadvantages: high degree overfits easily, very bad at extrapolation
                 (predicting outside the range of the training data),
                 sensitive to outliers.

8. APPLICATIONS
---------------
  Growth rate of populations, temperature over time, projectile motion,
  disease spread curves.

9. POSSIBLE VIVA QUESTIONS
--------------------------
Q1: Is polynomial regression linear or non-linear?
A:  The curve is non-linear with respect to x because of terms like x^2 and
    x^3. But the model is still linear in its coefficients b0, b1, b2, which
    are only multiplied by known values. That is why we can create new
    features x, x^2, ... and solve it using ordinary linear regression.

Q2: What happens if the degree is too low or too high?
A:  If the degree is too low, the curve is too simple to follow the pattern -
    this is underfitting, with high error on both training and test data. If
    the degree is too high, the curve bends to pass through every training
    point including noise - this is overfitting, with very low training error
    but high test error. The best degree is chosen using cross-validation.

Q3: What is the bias-variance trade-off?
A:  Bias is error from a model that is too simple and misses the pattern;
    variance is error from a model that is too sensitive to the training
    data. Increasing model complexity (higher degree) reduces bias but
    increases variance. The goal is to find a balance where the total test
    error is lowest.

Q4: What does PolynomialFeatures do?
A:  It creates new feature columns by raising the original features to
    powers. With degree 2 and one feature x, it gives [1, x, x^2]. With more
    than one feature it also creates products like x1*x2 (interaction terms).
    These new columns are then passed to LinearRegression.

Q5: What is a pipeline and why did we use it?
A:  A pipeline joins several steps (here PolynomialFeatures then
    LinearRegression) into one object. Calling fit or predict runs all steps
    in order automatically. It keeps the code short and makes sure the same
    transformation is applied correctly inside each cross-validation fold.

Q6: Why is polynomial regression bad at extrapolation?
A:  Outside the range of the training data, polynomial terms like x^3 grow
    very fast, so the curve can shoot up or down sharply. The predictions
    then become unrealistic. So polynomial models should only be trusted
    within the range of data they were trained on.
'''
