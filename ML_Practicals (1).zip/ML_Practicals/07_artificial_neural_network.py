# Practical 7: Artificial Neural Network (Multi-Layer Perceptron)
# Dataset: Breast Cancer Wisconsin (UCI Machine Learning Repository)
# Goal: Predict whether a tumour is malignant (0) or benign (1)

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import make_pipeline
from sklearn.metrics import confusion_matrix, accuracy_score, recall_score, f1_score, roc_auc_score

# Step 1: Load the dataset
data = load_breast_cancer()
X = data.data
y = data.target

# Step 2: Split into training set (80%) and test set (20%)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 3: Create and train the ANN
# 2 hidden layers: 16 neurons and 8 neurons, ReLU activation
ann = MLPClassifier(hidden_layer_sizes=(16, 8), activation="relu",
                    max_iter=1000, random_state=42)
model = make_pipeline(StandardScaler(), ann)   # neural networks need scaled data
model.fit(X_train, y_train)

# Step 4: Predict on the test set
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]

# Step 5: Calculate evaluation metrics
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
accuracy = accuracy_score(y_test, y_pred)
error = 1 - accuracy
recall = recall_score(y_test, y_pred)
specificity = tn / (tn + fp)
f1 = f1_score(y_test, y_pred)
auc = roc_auc_score(y_test, y_prob)

print("===== Artificial Neural Network =====")
print("True Positive  (TP):", tp)
print("True Negative  (TN):", tn)
print("False Positive (FP):", fp)
print("False Negative (FN):", fn)
print("Accuracy    :", round(accuracy, 4))
print("Error       :", round(error, 4))
print("Recall      :", round(recall, 4))
print("Specificity :", round(specificity, 4))
print("F1-score    :", round(f1, 4))
print("AUC         :", round(auc, 4))

# Step 6: K-fold cross-validation (k = 5)
scores = cross_val_score(model, X, y, cv=5, scoring="accuracy")
print("\n5-Fold Cross-Validation Accuracy:", scores.round(4))
print("Mean CV Accuracy:", round(scores.mean(), 4))


# =====================================================================
#                    THEORY AND EXPLANATION
# =====================================================================
'''
1. WHAT IS AN ARTIFICIAL NEURAL NETWORK (ANN)?
----------------------------------------------
An ANN is a model inspired by the human brain. It is made of small
units called NEURONS arranged in LAYERS. It can learn very complex,
non-linear patterns.

2. STRUCTURE (Multi-Layer Perceptron, MLP)
------------------------------------------
  Input layer   -> one neuron per feature (30 here)
  Hidden layers -> do the learning. Here: hidden_layer_sizes=(16, 8)
                   means 1st hidden layer has 16 neurons, 2nd has 8.
  Output layer  -> gives the final prediction (class 0 or 1)

  Input(30) ---> Hidden1(16) ---> Hidden2(8) ---> Output(1)

3. WHAT ONE NEURON DOES
-----------------------
  z = w1*x1 + w2*x2 + ... + wn*xn + b     (weighted sum + bias)
  a = f(z)                                (activation function)

  w = weights (how important each input is), b = bias.

4. ACTIVATION FUNCTIONS
-----------------------
  ReLU     : f(z) = max(0, z)            -> used in hidden layers here
  Sigmoid  : f(z) = 1 / (1 + e^(-z))     -> output between 0 and 1
  Tanh     : f(z) = (e^z - e^(-z)) / (e^z + e^(-z))  -> output between -1 and 1
  Softmax  : used in output layer for multi-class problems

  Without activation functions, the whole network would just be one
  linear model. Activations add NON-LINEARITY.

5. HOW THE NETWORK LEARNS
-------------------------
  a) FORWARD PROPAGATION: input passes layer by layer to give a prediction.
  b) LOSS: compare prediction with actual answer using log loss
          Loss = -[ y*log(p) + (1-y)*log(1-p) ]
  c) BACKPROPAGATION: using the chain rule of calculus, find how much each
     weight caused the error (the gradient).
  d) GRADIENT DESCENT: update every weight in the direction that reduces loss:
          w_new = w_old - learning_rate * (d Loss / d w)
  e) Repeat for many EPOCHS (passes over the training data).
     max_iter=1000 = maximum number of epochs.

  sklearn's MLPClassifier uses the "adam" optimiser by default,
  an improved version of gradient descent.

6. HOW THE PROGRAM WORKS
------------------------
  a) Load Breast Cancer dataset, split 80/20.
  b) Pipeline: StandardScaler -> MLPClassifier.
     Neural networks NEED scaled data, otherwise large-valued features
     dominate and training becomes slow or unstable.
  c) Train, predict class and probability, compute all metrics.
  d) 5-fold cross-validation.


CONFUSION MATRIX
----------------
                       Predicted Positive   Predicted Negative
  Actual Positive            TP                   FN
  Actual Negative            FP                   TN

  TP (True Positive)  : actually positive, predicted positive  (correct)
  TN (True Negative)  : actually negative, predicted negative  (correct)
  FP (False Positive) : actually negative, predicted positive  (Type I error)
  FN (False Negative) : actually positive, predicted negative  (Type II error)
  sklearn's confusion_matrix(...).ravel() returns  tn, fp, fn, tp  (in this order).

EVALUATION METRICS AND FORMULAS
-------------------------------
  Accuracy    = (TP + TN) / (TP + TN + FP + FN)   -> fraction of correct predictions
  Error       = 1 - Accuracy = (FP + FN) / Total  -> fraction of wrong predictions
  Recall      = TP / (TP + FN)   (Sensitivity / True Positive Rate)
                -> out of all actual positives, how many we caught
  Specificity = TN / (TN + FP)   (True Negative Rate)
                -> out of all actual negatives, how many we correctly rejected
  Precision   = TP / (TP + FP)   -> out of predicted positives, how many are correct
  F1-score    = 2 * Precision * Recall / (Precision + Recall)
                -> balance of precision and recall (harmonic mean)
  AUC         = Area Under the ROC curve. ROC plots Recall (TPR) against
                False Positive Rate (1 - Specificity) at all thresholds.
                1.0 = perfect, 0.5 = random guessing.

TRAIN-TEST SPLIT AND K-FOLD CROSS-VALIDATION
--------------------------------------------
  Train-test split: model learns on 80% data and is tested on the unseen 20%.
  K-fold cross-validation (k = 5):
    1. Divide data into 5 equal folds.
    2. Train on 4 folds, test on the remaining 1.
    3. Repeat 5 times so each fold is the test set once.
    4. Average the 5 scores -> more reliable than a single split.

ADVANTAGES AND DISADVANTAGES
----------------------------
  Advantages: learns complex non-linear patterns, works for images, text,
              speech; very powerful with large data.
  Disadvantages: needs more data and time, many settings to tune
                 (layers, neurons, learning rate), works like a "black box"
                 (hard to explain), can overfit.

APPLICATIONS
------------
  Image recognition, speech recognition, language translation,
  medical diagnosis, stock prediction.

POSSIBLE VIVA QUESTIONS
-----------------------
Q1: What is an artificial neuron?
A:  A neuron takes several inputs, multiplies each by a weight, adds them up
    with a bias (z = w1x1 + ... + wnxn + b), and passes the result through an
    activation function. The output is then sent to the next layer. Weights
    decide how important each input is and are learned during training.

Q2: Why do we need activation functions?
A:  Activation functions add non-linearity to the network. Without them, no
    matter how many layers we stack, the whole network would act like a
    single linear model. Non-linearity lets the network learn complex
    curved patterns. ReLU is common in hidden layers, and sigmoid or softmax
    in the output layer.

Q3: What is backpropagation?
A:  Backpropagation is the algorithm used to train neural networks. After
    forward propagation gives a prediction and the loss is calculated, the
    error is sent backward through the network, and the chain rule is used
    to find how much each weight contributed to the error (its gradient).
    These gradients are then used by gradient descent to update the weights.

Q4: What is gradient descent and the learning rate?
A:  Gradient descent updates each weight a little in the direction that
    reduces the loss: w = w - learning_rate * gradient. The learning rate is
    the step size. If it is too large, training may jump around and not
    settle; if too small, training becomes very slow.

Q5: What is an epoch?
A:  An epoch is one complete pass of the entire training data through the
    network (forward and backward). Networks usually need many epochs to
    learn. In our program, max_iter=1000 sets the maximum number of epochs.

Q6: What is the difference between a perceptron and an MLP?
A:  A perceptron is a single neuron with no hidden layer, and it can only
    separate data with a straight line (linearly separable data, e.g. it
    cannot solve XOR). A Multi-Layer Perceptron has one or more hidden layers
    with non-linear activations, so it can learn complex non-linear
    boundaries.

Q7: How can you prevent overfitting in a neural network?
A:  By using more training data, reducing the number of layers or neurons,
    adding regularization (the alpha parameter in MLPClassifier), early
    stopping (stop training when validation score stops improving), and
    dropout in deep learning libraries.
'''
