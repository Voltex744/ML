# Practical 10: Support Vector Machine (SVM) Classification
# Dataset: Breast Cancer Wisconsin (UCI Machine Learning Repository)
# Goal: Predict whether a tumour is malignant (0) or benign (1)

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix, accuracy_score, recall_score, f1_score, roc_auc_score

# Step 1: Load the dataset
data = load_breast_cancer()
X = data.data
y = data.target

# Step 2: Split into training set (80%) and test set (20%)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 3: Scale the features (mean 0, standard deviation 1)
# fit_transform on training data = learn mean/std AND scale it
# transform on test data = scale it using the SAME mean/std from training
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Step 4: Create and train the model
# kernel can be "linear", "rbf", "poly"; probability=True lets us compute AUC
model = SVC(kernel="rbf", C=1.0, probability=True, random_state=42)
model.fit(X_train, y_train)

# Step 5: Predict on the test set
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]

# Step 6: Calculate evaluation metrics
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
accuracy = accuracy_score(y_test, y_pred)
error = 1 - accuracy
recall = recall_score(y_test, y_pred)
specificity = tn / (tn + fp)
f1 = f1_score(y_test, y_pred)
auc = roc_auc_score(y_test, y_prob)

print("===== SVM Classifier (RBF kernel) =====")
print("True Positive  (TP):", tp)
print("True Negative  (TN):", tn)
print("False Positive (FP):", fp)
print("False Negative (FN):", fn)
print("Accuracy    :", round(accuracy, 4))
print("Error       :", round(error, 4))
print("Recall      :", round(recall, 4))
print("Specificity :", round(specificity, 4))
print("F1-score    :", round(f1, 4))
print("AUC         :", round(auc, 4))

# Step 7: K-fold cross-validation (k = 5)
X_scaled = StandardScaler().fit_transform(X)   # scale the full data for cross-validation
scores = cross_val_score(model, X_scaled, y, cv=5, scoring="accuracy")
print("\n5-Fold Cross-Validation Accuracy:", scores.round(4))
print("Mean CV Accuracy:", round(scores.mean(), 4))


# =====================================================================
#                    THEORY AND EXPLANATION
# =====================================================================
'''
1. WHAT IS SVM?
---------------
Support Vector Machine is a classification algorithm that finds the BEST
BOUNDARY (called a HYPERPLANE) that separates the classes with the
MAXIMUM MARGIN.

  Hyperplane     -> the separating line (2D), plane (3D), or hyperplane (more dimensions)
                    Equation:  w . x + b = 0
  Margin         -> distance between the hyperplane and the nearest points of each class
  Support vectors-> the data points closest to the hyperplane. Only these
                    points decide where the boundary is.

  Wider margin = better generalisation on new data.

2. MATHEMATICS (HARD MARGIN)
----------------------------
  Classify:   if w . x + b >= 0 -> class +1, else class -1
  Margin width = 2 / ||w||
  To maximise the margin, SVM minimises:
        (1/2) * ||w||^2
  subject to:  yi * (w . xi + b) >= 1  for every training point

3. SOFT MARGIN AND THE C PARAMETER
----------------------------------
Real data is not perfectly separable, so SVM allows some mistakes.
  C = penalty for misclassified points (here C = 1.0)
    Large C -> few mistakes allowed, narrow margin -> risk of overfitting
    Small C -> more mistakes allowed, wide margin  -> smoother, may underfit

4. KERNEL TRICK (for non-linear data)
-------------------------------------
If the data cannot be separated by a straight line, a KERNEL maps the
data into a higher dimension where it CAN be separated, without actually
calculating the new coordinates.

  Linear kernel     : K(x, y) = x . y
  Polynomial kernel : K(x, y) = (x . y + c)^d
  RBF (Gaussian)    : K(x, y) = exp( -gamma * ||x - y||^2 )   <- used here
  Sigmoid kernel    : K(x, y) = tanh( a * (x . y) + c )

  gamma (RBF) controls how far the influence of one point reaches.

5. HOW THE PROGRAM WORKS
------------------------
  a) Load Breast Cancer dataset, split 80/20.
  b) StandardScaler is fit on the training data and applied to the test
     data, then SVC(kernel="rbf", C=1.0, probability=True) is trained on
     the scaled data.
     SVM depends on distances, so scaling is very important.
     probability=True makes SVM also give probabilities (needed for AUC).
  c) Predict class and probability, compute all metrics.
  d) 5-fold cross-validation.


CONFUSION MATRIX
----------------
                       Predicted Positive   Predicted Negative
  Actual Positive            TP                   FN
  Actual Negative            FP                   TN

  TP (True Positive)  : actually positive, predicted positive  (correct)
  TN (True Negative)  : actually negative, predicted negative  (correct)
  FP (False Positive) : actually negative, predicted positive  (Type I error)
  FN (False Negative) : actually positive, predicted negative  (Type II error)
  sklearn's confusion_matrix(...).ravel() returns  tn, fp, fn, tp  (in this order).

EVALUATION METRICS AND FORMULAS
-------------------------------
  Accuracy    = (TP + TN) / (TP + TN + FP + FN)   -> fraction of correct predictions
  Error       = 1 - Accuracy = (FP + FN) / Total  -> fraction of wrong predictions
  Recall      = TP / (TP + FN)   (Sensitivity / True Positive Rate)
                -> out of all actual positives, how many we caught
  Specificity = TN / (TN + FP)   (True Negative Rate)
                -> out of all actual negatives, how many we correctly rejected
  Precision   = TP / (TP + FP)   -> out of predicted positives, how many are correct
  F1-score    = 2 * Precision * Recall / (Precision + Recall)
                -> balance of precision and recall (harmonic mean)
  AUC         = Area Under the ROC curve. ROC plots Recall (TPR) against
                False Positive Rate (1 - Specificity) at all thresholds.
                1.0 = perfect, 0.5 = random guessing.

TRAIN-TEST SPLIT AND K-FOLD CROSS-VALIDATION
--------------------------------------------
  Train-test split: model learns on 80% data and is tested on the unseen 20%.
  K-fold cross-validation (k = 5):
    1. Divide data into 5 equal folds.
    2. Train on 4 folds, test on the remaining 1.
    3. Repeat 5 times so each fold is the test set once.
    4. Average the 5 scores -> more reliable than a single split.

ADVANTAGES AND DISADVANTAGES
----------------------------
  Advantages: very accurate, works well in high dimensions, kernels handle
              non-linear data, less overfitting due to maximum margin.
  Disadvantages: slow on very large datasets, choosing kernel/C/gamma is
                 tricky, needs scaling, harder to interpret.

APPLICATIONS
------------
  Face detection, text and image classification, handwriting recognition,
  bioinformatics (protein / cancer classification).

POSSIBLE VIVA QUESTIONS
-----------------------
Q1: What are support vectors?
A:  Support vectors are the training points that lie closest to the
    separating hyperplane, on the edge of the margin. Only these points
    decide the position of the hyperplane; removing other points would not
    change it. That is why the algorithm is called Support Vector Machine.

Q2: What is the margin and why maximise it?
A:  The margin is the distance between the hyperplane and the nearest data
    points of each class, equal to 2 / ||w||. SVM chooses the hyperplane with
    the largest margin. A wider margin gives more room for error on new data,
    so the model generalises better.

Q3: What is the kernel trick?
A:  When data cannot be separated by a straight line, a kernel function maps
    it into a higher-dimensional space where it becomes separable. The trick
    is that SVM only needs dot products, which the kernel calculates directly
    without actually creating the high-dimensional features. This saves a
    lot of computation.

Q4: Name some kernels and when to use them.
A:  Linear kernel is used when data is roughly linearly separable or has very
    many features (like text). Polynomial kernel captures curved boundaries
    of a fixed degree. RBF (Gaussian) kernel is the most flexible and is the
    default; it works well when we do not know the shape of the boundary.

Q5: What is the role of the C parameter?
A:  C controls the trade-off between a wide margin and correctly classifying
    training points. A large C tries hard to classify every point correctly,
    giving a narrow margin and possible overfitting. A small C allows some
    mistakes for a wider, smoother margin, which may generalise better.

Q6: What is gamma in the RBF kernel?
A:  Gamma decides how far the influence of a single training point reaches.
    High gamma means each point affects only its close area, making a very
    wiggly boundary (overfitting). Low gamma means each point influences a
    wide area, giving a smoother boundary (possible underfitting).

Q7: What is the difference between hard margin and soft margin SVM?
A:  Hard margin SVM does not allow any point to be misclassified, so it works
    only when data is perfectly separable and is very sensitive to outliers.
    Soft margin SVM allows some points inside the margin or on the wrong side,
    controlled by C, so it works on real, noisy data.
'''
