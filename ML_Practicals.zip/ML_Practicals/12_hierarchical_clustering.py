# Practical 12: Hierarchical (Agglomerative) Clustering
# Dataset: Iris (UCI Machine Learning Repository)
# Goal: Group flowers into 3 clusters WITHOUT using the labels
# Clustering is unsupervised, so instead of accuracy we use:
#   - Silhouette score (how well separated the clusters are, -1 to 1, higher is better)
#   - Adjusted Rand Index (how close clusters are to the true species, 0 to 1)

import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import silhouette_score, adjusted_rand_score

# Step 1: Load the dataset
data = load_iris()
X = StandardScaler().fit_transform(data.data)   # scale features
y_true = data.target                            # used ONLY to check results

# Step 2: Draw the dendrogram (helps decide number of clusters)
Z = linkage(X, method="ward")
plt.figure(figsize=(12, 5))
dendrogram(Z)
plt.title("Dendrogram (Ward linkage)")
plt.xlabel("Data points")
plt.ylabel("Distance")
plt.show()

# Step 3: Train Agglomerative Clustering with 3 clusters
model = AgglomerativeClustering(n_clusters=3, linkage="ward")
labels = model.fit_predict(X)

# Step 4: Evaluation
print("===== Hierarchical Clustering (3 clusters, Ward linkage) =====")
print("Silhouette Score    :", round(silhouette_score(X, labels), 4))
print("Adjusted Rand Index :", round(adjusted_rand_score(y_true, labels), 4))
print("Points in each cluster:", [list(labels).count(i) for i in range(3)])

# Step 5: Plot the clusters (first two features)
plt.scatter(X[:, 0], X[:, 1], c=labels, cmap="viridis")
plt.xlabel("Sepal length (scaled)")
plt.ylabel("Sepal width (scaled)")
plt.title("Hierarchical Clusters")
plt.show()


# =====================================================================
#                    THEORY AND EXPLANATION
# =====================================================================
'''
1. WHAT IS HIERARCHICAL CLUSTERING?
-----------------------------------
Hierarchical clustering is UNSUPERVISED learning that builds a
TREE (hierarchy) of clusters. Unlike K-Means, you do not have to choose
the number of clusters at the start; you can decide later by cutting
the tree.

2. TWO TYPES
------------
  AGGLOMERATIVE (bottom-up)  <- used here
    1. Start with every point as its own cluster (n clusters).
    2. Find the two CLOSEST clusters and MERGE them.
    3. Repeat until only one cluster remains (or the required number).

  DIVISIVE (top-down)
    1. Start with all points in one cluster.
    2. Repeatedly SPLIT clusters until every point is alone.

3. LINKAGE METHODS (how to measure distance between two clusters)
----------------------------------------------------------------
  Single linkage   : distance between the two CLOSEST points of the clusters
                     (can create long chain-like clusters)
  Complete linkage : distance between the two FARTHEST points
                     (gives compact clusters)
  Average linkage  : AVERAGE distance between all pairs of points
  Ward linkage     : merges the two clusters that cause the SMALLEST
                     increase in total within-cluster variance  <- used here
                     (gives clusters similar to K-Means)

  Distance between points is usually Euclidean:
    d = sqrt( (x1 - y1)^2 + (x2 - y2)^2 + ... )

4. DENDROGRAM
-------------
A dendrogram is a tree diagram that shows the order in which clusters
were merged.
  - x-axis: data points
  - y-axis: distance at which clusters were merged
  - Height of a joining line = how different the two merged clusters are.

  HOW TO CHOOSE THE NUMBER OF CLUSTERS:
  Draw a horizontal line across the dendrogram where the vertical lines
  are LONGEST (biggest gap). The number of vertical lines your
  horizontal line cuts = number of clusters. For Iris this gives 2 or 3.

5. EVALUATION METRICS FOR CLUSTERING
------------------------------------
Clustering has no labels, so accuracy, train-test split and
cross-validation do not apply. We use:

  SILHOUETTE SCORE (no labels needed):
      a = average distance to points in own cluster
      b = average distance to points in nearest other cluster
      s = (b - a) / max(a, b)       -> averaged over all points
      Range -1 to +1. Higher = better separated clusters.

  ADJUSTED RAND INDEX (ARI) (uses true labels only for checking):
      1 = clusters match the real classes perfectly, 0 = random.

6. HOW THE PROGRAM WORKS
------------------------
  a) Load Iris dataset (150 flowers, 4 features). Labels kept only for ARI.
  b) StandardScaler to bring features to the same scale.
  c) linkage(X, method="ward") calculates the full merge history,
     and dendrogram() draws it.
  d) AgglomerativeClustering(n_clusters=3, linkage="ward") gives each
     flower a cluster number.
  e) Print silhouette score, ARI and number of points in each cluster.
  f) Plot clusters using the first two features.

7. K-MEANS vs HIERARCHICAL CLUSTERING
-------------------------------------
  | K-Means                          | Hierarchical                        |
  |----------------------------------|-------------------------------------|
  | K must be chosen before          | Number of clusters chosen later     |
  | Fast, good for large data        | Slow (O(n^2) memory), small data    |
  | Result depends on random start   | Same result every time              |
  | No tree diagram                  | Gives a dendrogram                  |

8. ADVANTAGES AND DISADVANTAGES
-------------------------------
  Advantages: no need to fix number of clusters in advance, dendrogram is
              easy to interpret, deterministic (same output every time).
  Disadvantages: slow and memory-heavy for large datasets, a merge once
                 done cannot be undone, sensitive to noise and outliers.

9. APPLICATIONS
---------------
  Gene / species classification (biology), document organisation,
  social network analysis, customer grouping.

10. POSSIBLE VIVA QUESTIONS
--------------------------
Q1: What is a dendrogram?
A:  A dendrogram is a tree diagram that shows the order in which clusters were
    merged (or split). The x-axis shows the data points and the y-axis shows
    the distance at which two clusters were joined. Taller joining lines mean
    the merged clusters were very different.

Q2: What is the difference between agglomerative and divisive clustering?
A:  Agglomerative is bottom-up: it starts with each point as its own cluster
    and repeatedly merges the two closest clusters. Divisive is top-down: it
    starts with all points in one cluster and repeatedly splits it.
    Agglomerative is more commonly used and is what sklearn provides.

Q3: Explain the different linkage methods.
A:  Single linkage uses the distance between the closest points of two
    clusters and can form long chains. Complete linkage uses the farthest
    points and gives compact clusters. Average linkage uses the average of
    all pairwise distances. Ward linkage merges the pair that increases total
    variance the least, giving balanced clusters similar to K-Means.

Q4: How do you decide the number of clusters from a dendrogram?
A:  Look for the longest vertical lines that are not crossed by any
    horizontal merge line, i.e. the biggest jump in distance. Draw a
    horizontal line through this gap; the number of vertical lines it cuts is
    the number of clusters. For Iris, this suggests 2 or 3 clusters.

Q5: What are the differences between K-Means and hierarchical clustering?
A:  K-Means needs K in advance, is fast and suitable for large data, but
    depends on random starting points. Hierarchical clustering does not need
    the number of clusters in advance, gives a dendrogram, and always gives
    the same result, but it is slow and needs a lot of memory for large data.

Q6: Why can't we use train-test split or accuracy for clustering?
A:  These methods need the correct answers (labels) to compare predictions
    with. Clustering is unsupervised and has no labels, so we use internal
    measures like the silhouette score. If true labels happen to be available,
    like in Iris, we can use ARI only to check how good the clusters are.
'''
