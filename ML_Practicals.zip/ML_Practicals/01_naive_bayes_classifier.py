# Practical 1: Naive Bayes Classifier
# Dataset: Breast Cancer Wisconsin (UCI Machine Learning Repository)
# Goal: Predict whether a tumour is malignant (0) or benign (1)

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix, accuracy_score, recall_score, f1_score, roc_auc_score

# Step 1: Load the dataset
data = load_breast_cancer()
X = data.data      # input features
y = data.target    # output labels (0 = malignant, 1 = benign)

# Step 2: Split into training set (80%) and test set (20%)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 3: Create and train the model
model = GaussianNB()
model.fit(X_train, y_train)

# Step 4: Predict on the test set
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]   # probabilities, needed for AUC

# Step 5: Calculate evaluation metrics
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
accuracy = accuracy_score(y_test, y_pred)
error = 1 - accuracy
recall = recall_score(y_test, y_pred)
specificity = tn / (tn + fp)
f1 = f1_score(y_test, y_pred)
auc = roc_auc_score(y_test, y_prob)

print("===== Naive Bayes Classifier =====")
print("True Positive  (TP):", tp)
print("True Negative  (TN):", tn)
print("False Positive (FP):", fp)
print("False Negative (FN):", fn)
print("Accuracy    :", round(accuracy, 4))
print("Error       :", round(error, 4))
print("Recall      :", round(recall, 4))
print("Specificity :", round(specificity, 4))
print("F1-score    :", round(f1, 4))
print("AUC         :", round(auc, 4))

# Step 6: K-fold cross-validation (k = 5)
scores = cross_val_score(model, X, y, cv=5, scoring="accuracy")
print("\n5-Fold Cross-Validation Accuracy:", scores.round(4))
print("Mean CV Accuracy:", round(scores.mean(), 4))


# =====================================================================
#                    THEORY AND EXPLANATION
# =====================================================================
'''
1. WHAT IS NAIVE BAYES?
-----------------------
Naive Bayes is a CLASSIFICATION algorithm based on probability.
It uses BAYES' THEOREM to find the probability that a data point belongs
to each class, and then picks the class with the highest probability.

It is called "NAIVE" because it assumes that all features are
INDEPENDENT of each other (for example, it assumes tumour radius and
tumour texture do not affect each other). This is rarely true in real
life, but the algorithm still works very well in practice.

2. BAYES' THEOREM
-----------------
            P(X | C) * P(C)
  P(C | X) = ---------------
                 P(X)

  P(C | X) = Posterior   -> probability of class C given the features X
  P(X | C) = Likelihood  -> probability of seeing features X if class is C
  P(C)     = Prior       -> how common class C is in the training data
  P(X)     = Evidence    -> probability of features X (same for all classes,
                            so we can ignore it when comparing classes)

With the naive (independence) assumption, for features x1, x2, ..., xn:

  P(C | X)  is proportional to  P(C) * P(x1|C) * P(x2|C) * ... * P(xn|C)

Predicted class = the class C that gives the MAXIMUM value of the above.

3. GAUSSIAN NAIVE BAYES (used in this program)
----------------------------------------------
Our features are continuous numbers (radius, area, etc.), so we assume
each feature follows a NORMAL (Gaussian / bell-curve) distribution
inside each class:

                       1                    (x - mean)^2
  P(x | C) = --------------------- * exp( - ------------- )
              sqrt(2 * pi * var)              2 * var

  mean and var (variance) are calculated from the training data
  for each feature and each class.

Other types:
  - Multinomial NB -> for counts (e.g. word counts in text / spam filter)
  - Bernoulli NB   -> for yes/no (0/1) features

4. HOW THE PROGRAM WORKS
------------------------
  a) Load the Breast Cancer dataset: 569 patients, 30 features,
     2 classes (0 = malignant, 1 = benign).
  b) train_test_split -> 80% data for training, 20% for testing.
     random_state=42 makes the split the same every time.
  c) model.fit() -> calculates prior, mean and variance for each class.
  d) model.predict() -> gives the class; predict_proba() gives probabilities.
  e) Calculate all evaluation metrics on the test set.
  f) cross_val_score with cv=5 -> 5-fold cross-validation.

5. CONFUSION MATRIX
-------------------
                       Predicted Positive   Predicted Negative
  Actual Positive            TP                   FN
  Actual Negative            FP                   TN

  TP (True Positive)  : actually positive, predicted positive  (correct)
  TN (True Negative)  : actually negative, predicted negative  (correct)
  FP (False Positive) : actually negative, predicted positive  (wrong, Type I error)
  FN (False Negative) : actually positive, predicted negative  (wrong, Type II error)

  In sklearn, confusion_matrix(...).ravel() returns  tn, fp, fn, tp  (in this order).

6. EVALUATION METRICS AND FORMULAS
----------------------------------
  Accuracy    = (TP + TN) / (TP + TN + FP + FN)
                -> fraction of all predictions that are correct

  Error       = 1 - Accuracy = (FP + FN) / Total
                -> fraction of predictions that are wrong

  Recall      = TP / (TP + FN)     (also called Sensitivity or True Positive Rate)
                -> out of all actual positives, how many did we catch?

  Specificity = TN / (TN + FP)     (True Negative Rate)
                -> out of all actual negatives, how many did we correctly reject?

  Precision   = TP / (TP + FP)
                -> out of all predicted positives, how many are really positive?

  F1-score    = 2 * Precision * Recall / (Precision + Recall)
                -> harmonic mean of precision and recall; useful when classes
                   are imbalanced

  AUC (Area Under the ROC Curve)
                -> ROC curve plots True Positive Rate (Recall) vs
                   False Positive Rate (1 - Specificity) at different thresholds.
                -> AUC = area under that curve, between 0 and 1.
                   1.0 = perfect, 0.5 = random guessing.

7. TRAIN-TEST SPLIT AND K-FOLD CROSS-VALIDATION
-----------------------------------------------
  Train-Test Split:
    Data is divided into two parts. The model learns from the training
    part and is tested on the unseen test part. This tells us how well
    the model works on NEW data.

  K-Fold Cross-Validation (here k = 5):
    1. Divide the whole dataset into k equal parts (folds).
    2. Train on k-1 folds, test on the remaining 1 fold.
    3. Repeat k times so that every fold is used as the test set once.
    4. Final score = average of the k scores.
    It gives a more reliable estimate than a single split, because
    every data point is used for both training and testing.

8. ADVANTAGES AND DISADVANTAGES
-------------------------------
  Advantages:
    - Very fast and simple
    - Works well with small data and many features
    - Works very well for text classification (spam filtering)
  Disadvantages:
    - Assumes features are independent (often not true)
    - Zero-frequency problem: if a value never appears in training for a
      class, its probability becomes 0 (solved by Laplace smoothing)

9. APPLICATIONS
---------------
  Spam filtering, sentiment analysis, document classification,
  medical diagnosis, recommendation systems.

10. POSSIBLE VIVA QUESTIONS
--------------------------
Q1: Why is it called "Naive" Bayes?
A:  It is called naive because it assumes that all features are completely
    independent of each other, given the class. For example, it assumes the
    radius of a tumour tells us nothing about its texture. This is rarely true
    in real data, but the assumption makes the calculation very simple
    (we just multiply individual probabilities), and the model still gives
    good results in practice.

Q2: State Bayes' theorem and explain each term.
A:  P(C|X) = P(X|C) * P(C) / P(X). P(C|X) is the posterior, the probability of
    the class after seeing the data. P(X|C) is the likelihood, how probable the
    data is if the class is C. P(C) is the prior, how common the class is
    overall. P(X) is the evidence, which is the same for every class, so it is
    ignored when comparing classes.

Q3: What is prior probability and how is it calculated?
A:  Prior probability is the probability of a class before looking at any
    feature. It is calculated from the training data as
    (number of samples of that class) / (total number of samples). For
    example, if 60 out of 100 tumours are benign, P(benign) = 0.6.

Q4: What are the types of Naive Bayes and when is each used?
A:  Gaussian NB is used when features are continuous numbers and assumes a
    normal (bell-shaped) distribution - that is why we used it here.
    Multinomial NB is used for count data, like how many times a word appears
    in a document. Bernoulli NB is used when features are binary (0/1), like
    whether a word is present or not.

Q5: What is the zero-frequency problem and how is it solved?
A:  If a feature value never appears with a class in the training data, its
    probability becomes 0, and since we multiply probabilities, the whole
    result becomes 0. This is solved with Laplace (add-one) smoothing, where
    we add 1 to every count so no probability is ever exactly zero.

Q6: What is the difference between recall and specificity?
A:  Recall (sensitivity) = TP / (TP + FN) tells how many actual positives the
    model correctly found. Specificity = TN / (TN + FP) tells how many actual
    negatives the model correctly rejected. In medical tests, high recall
    means few sick patients are missed, and high specificity means few healthy
    patients are wrongly flagged.

Q7: Why do we use k-fold cross-validation instead of only a train-test split?
A:  A single train-test split depends on which rows happened to go into the
    test set, so the score can be lucky or unlucky. In k-fold
    cross-validation every data point is used for testing exactly once, and
    we average k scores. This gives a more stable and reliable estimate of
    how the model will perform on new data.
'''
