# Practical 6: Logistic Regression
# Dataset: Breast Cancer Wisconsin (UCI Machine Learning Repository)
# Goal: Predict whether a tumour is malignant (0) or benign (1)

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, accuracy_score, recall_score, f1_score, roc_auc_score

# Step 1: Load the dataset
data = load_breast_cancer()
X = data.data
y = data.target

# Step 2: Split into training set (80%) and test set (20%)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 3: Scale the features (mean 0, standard deviation 1)
# fit_transform on training data = learn mean/std AND scale it
# transform on test data = scale it using the SAME mean/std from training
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Step 4: Create and train the model (scaling the data first helps logistic regression)
model = LogisticRegression()
model.fit(X_train, y_train)

# Step 5: Predict on the test set
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]

# Step 6: Calculate evaluation metrics
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
accuracy = accuracy_score(y_test, y_pred)
error = 1 - accuracy
recall = recall_score(y_test, y_pred)
specificity = tn / (tn + fp)
f1 = f1_score(y_test, y_pred)
auc = roc_auc_score(y_test, y_prob)

print("===== Logistic Regression =====")
print("True Positive  (TP):", tp)
print("True Negative  (TN):", tn)
print("False Positive (FP):", fp)
print("False Negative (FN):", fn)
print("Accuracy    :", round(accuracy, 4))
print("Error       :", round(error, 4))
print("Recall      :", round(recall, 4))
print("Specificity :", round(specificity, 4))
print("F1-score    :", round(f1, 4))
print("AUC         :", round(auc, 4))

# Step 7: K-fold cross-validation (k = 5)
X_scaled = StandardScaler().fit_transform(X)   # scale the full data for cross-validation
scores = cross_val_score(model, X_scaled, y, cv=5, scoring="accuracy")
print("\n5-Fold Cross-Validation Accuracy:", scores.round(4))
print("Mean CV Accuracy:", round(scores.mean(), 4))


# =====================================================================
#                    THEORY AND EXPLANATION
# =====================================================================
'''
1. WHAT IS LOGISTIC REGRESSION?
-------------------------------
Despite the name "regression", Logistic Regression is a CLASSIFICATION
algorithm. It predicts the PROBABILITY that a data point belongs to a
class (for example: probability that a tumour is benign).

2. HOW IT WORKS
---------------
Step 1: Calculate a linear combination of the features (like linear regression):
          z = b0 + b1*x1 + b2*x2 + ... + bn*xn

Step 2: Pass z through the SIGMOID (logistic) function, which squeezes
        any number into the range 0 to 1:

                         1
          sigmoid(z) = -----------
                       1 + e^(-z)

          z very large positive -> output close to 1
          z = 0                 -> output = 0.5
          z very large negative -> output close to 0

Step 3: Apply a THRESHOLD (default 0.5):
          if probability >= 0.5 -> class 1
          else                  -> class 0

The line/plane where probability = 0.5 is called the DECISION BOUNDARY.

3. COST FUNCTION (Log Loss / Binary Cross-Entropy)
--------------------------------------------------
We cannot use MSE here (it gives a non-convex curve). Instead we use:

  Cost = -(1/n) * sum of [ yi * log(pi) + (1 - yi) * log(1 - pi) ]

  yi = actual class (0 or 1), pi = predicted probability.
  If the model is confident and wrong, the cost becomes very large.
  The coefficients are found by minimising this cost using
  GRADIENT DESCENT (or similar optimisers).

  ODDS and LOG-ODDS: log( p / (1 - p) ) = z, so logistic regression is
  a linear model for the log-odds.

4. HOW THE PROGRAM WORKS
------------------------
  a) Load the Breast Cancer dataset (569 samples, 30 features, 2 classes).
  b) Split 80% training, 20% testing.
  c) StandardScaler changes each feature to mean 0 and std 1:
           z = (x - mean) / std
       This helps the optimiser converge faster.
       The scaler is FIT only on the training data (fit_transform) and then
       only APPLIED to the test data (transform), so no information from the
       test set leaks into training. Then LogisticRegression() is trained
       on the scaled training data.
  d) predict() gives class, predict_proba()[:, 1] gives probability of class 1.
  e) Compute confusion matrix and all metrics, then 5-fold CV.


CONFUSION MATRIX
----------------
                       Predicted Positive   Predicted Negative
  Actual Positive            TP                   FN
  Actual Negative            FP                   TN

  TP (True Positive)  : actually positive, predicted positive  (correct)
  TN (True Negative)  : actually negative, predicted negative  (correct)
  FP (False Positive) : actually negative, predicted positive  (Type I error)
  FN (False Negative) : actually positive, predicted negative  (Type II error)
  sklearn's confusion_matrix(...).ravel() returns  tn, fp, fn, tp  (in this order).

EVALUATION METRICS AND FORMULAS
-------------------------------
  Accuracy    = (TP + TN) / (TP + TN + FP + FN)   -> fraction of correct predictions
  Error       = 1 - Accuracy = (FP + FN) / Total  -> fraction of wrong predictions
  Recall      = TP / (TP + FN)   (Sensitivity / True Positive Rate)
                -> out of all actual positives, how many we caught
  Specificity = TN / (TN + FP)   (True Negative Rate)
                -> out of all actual negatives, how many we correctly rejected
  Precision   = TP / (TP + FP)   -> out of predicted positives, how many are correct
  F1-score    = 2 * Precision * Recall / (Precision + Recall)
                -> balance of precision and recall (harmonic mean)
  AUC         = Area Under the ROC curve. ROC plots Recall (TPR) against
                False Positive Rate (1 - Specificity) at all thresholds.
                1.0 = perfect, 0.5 = random guessing.

TRAIN-TEST SPLIT AND K-FOLD CROSS-VALIDATION
--------------------------------------------
  Train-test split: model learns on 80% data and is tested on the unseen 20%.
  K-fold cross-validation (k = 5):
    1. Divide data into 5 equal folds.
    2. Train on 4 folds, test on the remaining 1.
    3. Repeat 5 times so each fold is the test set once.
    4. Average the 5 scores -> more reliable than a single split.

ADVANTAGES AND DISADVANTAGES
----------------------------
  Advantages: simple, fast, gives probabilities, easy to interpret,
              less prone to overfitting (sklearn adds L2 regularization by default).
  Disadvantages: decision boundary is linear, so it cannot handle
                 complex non-linear patterns without extra features.

APPLICATIONS
------------
  Spam detection, disease diagnosis, credit default prediction,
  customer churn prediction.

POSSIBLE VIVA QUESTIONS
-----------------------
Q1: Why is logistic regression used for classification even though it is called regression?
A:  It first calculates a linear combination of features like linear
    regression, but then passes it through the sigmoid function to get a
    probability between 0 and 1. A threshold (usually 0.5) converts this
    probability into a class. So it "regresses" the probability, but the
    final output is a class label.

Q2: What is the sigmoid function and why is it used?
A:  The sigmoid function is 1 / (1 + e^(-z)). It converts any real number into
    a value between 0 and 1, which can be read as a probability. Large
    positive z gives values near 1, large negative z gives values near 0,
    and z = 0 gives 0.5.

Q3: What cost function is used and why not MSE?
A:  Logistic regression uses log loss (binary cross-entropy):
    -[y log(p) + (1 - y) log(1 - p)]. It strongly punishes confident wrong
    predictions. MSE is not used because, combined with the sigmoid, it
    creates a non-convex curve with many local minima, making gradient
    descent unreliable.

Q4: What is a decision boundary?
A:  The decision boundary is the line (or plane) where the predicted
    probability is exactly 0.5, i.e. where z = 0. Points on one side are
    classified as class 1 and on the other side as class 0. In logistic
    regression this boundary is always linear in the features.

Q5: What are odds and log-odds?
A:  Odds = p / (1 - p), the ratio of the probability of an event happening
    to it not happening. Log-odds is log(p / (1 - p)), which logistic
    regression models as a linear function of the features. So each
    coefficient tells how much the log-odds change for a one unit increase
    in that feature.

Q6: How can logistic regression handle more than two classes?
A:  Using One-vs-Rest, where a separate binary model is trained for each
    class against all others, and the class with the highest probability
    wins. Or using multinomial (softmax) logistic regression, which predicts
    probabilities for all classes at once so they add up to 1.

Q7: Why is AUC useful?
A:  Accuracy depends on one threshold (0.5), but AUC checks the model's
    performance at all thresholds. It tells how well the model ranks
    positive cases above negative cases. AUC is also more reliable than
    accuracy when classes are imbalanced.
'''
