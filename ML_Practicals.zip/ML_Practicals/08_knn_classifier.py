# Practical 8: K-Nearest Neighbours (K-NN) Classifier
# Dataset: Breast Cancer Wisconsin (UCI Machine Learning Repository)
# Goal: Predict whether a tumour is malignant (0) or benign (1)

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, accuracy_score, recall_score, f1_score, roc_auc_score

# Step 1: Load the dataset
data = load_breast_cancer()
X = data.data
y = data.target

# Step 2: Split into training set (80%) and test set (20%)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 3: Scale the features (mean 0, standard deviation 1)
# fit_transform on training data = learn mean/std AND scale it
# transform on test data = scale it using the SAME mean/std from training
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Step 4: Create and train the model (K = 5 neighbours)
model = KNeighborsClassifier(n_neighbors=5)
model.fit(X_train, y_train)

# Step 5: Predict on the test set
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]

# Step 6: Calculate evaluation metrics
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
accuracy = accuracy_score(y_test, y_pred)
error = 1 - accuracy
recall = recall_score(y_test, y_pred)
specificity = tn / (tn + fp)
f1 = f1_score(y_test, y_pred)
auc = roc_auc_score(y_test, y_prob)

print("===== K-NN Classifier (K = 5) =====")
print("True Positive  (TP):", tp)
print("True Negative  (TN):", tn)
print("False Positive (FP):", fp)
print("False Negative (FN):", fn)
print("Accuracy    :", round(accuracy, 4))
print("Error       :", round(error, 4))
print("Recall      :", round(recall, 4))
print("Specificity :", round(specificity, 4))
print("F1-score    :", round(f1, 4))
print("AUC         :", round(auc, 4))

# Step 7: K-fold cross-validation (k = 5)
X_scaled = StandardScaler().fit_transform(X)   # scale the full data for cross-validation
scores = cross_val_score(model, X_scaled, y, cv=5, scoring="accuracy")
print("\n5-Fold Cross-Validation Accuracy:", scores.round(4))
print("Mean CV Accuracy:", round(scores.mean(), 4))


# =====================================================================
#                    THEORY AND EXPLANATION
# =====================================================================
'''
1. WHAT IS K-NN?
----------------
K-Nearest Neighbours is a simple classification algorithm. To classify
a new point, it looks at the K closest points in the training data and
takes a MAJORITY VOTE of their classes.

  "Tell me who your neighbours are, and I will tell you who you are."

It is called a LAZY LEARNER (instance-based learning) because it does
not build a model during training; it just stores the data. All the
work happens at prediction time.

2. ALGORITHM STEPS
------------------
  1. Choose K (here K = 5).
  2. For a new point, calculate its distance to every training point.
  3. Pick the K points with the smallest distance.
  4. Count the classes among these K neighbours.
  5. Assign the class that appears most (majority vote).
  Probability (for AUC) = fraction of neighbours in class 1, e.g. 4/5 = 0.8.

3. DISTANCE FORMULAS
--------------------
  Euclidean distance (default):
    d = sqrt( (x1 - y1)^2 + (x2 - y2)^2 + ... + (xn - yn)^2 )

  Manhattan distance:
    d = |x1 - y1| + |x2 - y2| + ... + |xn - yn|

  Minkowski distance (general form):
    d = ( sum of |xi - yi|^p )^(1/p)
    p = 1 -> Manhattan, p = 2 -> Euclidean

4. CHOOSING K
-------------
  K too small (e.g. 1) -> very sensitive to noise -> OVERFITTING
  K too large          -> includes far-away points -> UNDERFITTING
  Usually choose an ODD K for two classes (to avoid ties), and pick
  the best K using cross-validation.

5. WHY SCALING IS NECESSARY
---------------------------
K-NN uses distance. If one feature is in thousands (area) and another is
between 0 and 1 (smoothness), the large feature will control the distance
completely. StandardScaler makes all features comparable:
    z = (x - mean) / std

6. HOW THE PROGRAM WORKS
------------------------
  a) Load Breast Cancer dataset, split 80/20.
  b) StandardScaler is fit on the training data and applied to the test
     data (K-NN uses distance, so scaling is needed), then
     KNeighborsClassifier(n_neighbors=5) is trained on the scaled data.
  c) Predict class and probability, compute all metrics.
  d) 5-fold cross-validation.


CONFUSION MATRIX
----------------
                       Predicted Positive   Predicted Negative
  Actual Positive            TP                   FN
  Actual Negative            FP                   TN

  TP (True Positive)  : actually positive, predicted positive  (correct)
  TN (True Negative)  : actually negative, predicted negative  (correct)
  FP (False Positive) : actually negative, predicted positive  (Type I error)
  FN (False Negative) : actually positive, predicted negative  (Type II error)
  sklearn's confusion_matrix(...).ravel() returns  tn, fp, fn, tp  (in this order).

EVALUATION METRICS AND FORMULAS
-------------------------------
  Accuracy    = (TP + TN) / (TP + TN + FP + FN)   -> fraction of correct predictions
  Error       = 1 - Accuracy = (FP + FN) / Total  -> fraction of wrong predictions
  Recall      = TP / (TP + FN)   (Sensitivity / True Positive Rate)
                -> out of all actual positives, how many we caught
  Specificity = TN / (TN + FP)   (True Negative Rate)
                -> out of all actual negatives, how many we correctly rejected
  Precision   = TP / (TP + FP)   -> out of predicted positives, how many are correct
  F1-score    = 2 * Precision * Recall / (Precision + Recall)
                -> balance of precision and recall (harmonic mean)
  AUC         = Area Under the ROC curve. ROC plots Recall (TPR) against
                False Positive Rate (1 - Specificity) at all thresholds.
                1.0 = perfect, 0.5 = random guessing.

TRAIN-TEST SPLIT AND K-FOLD CROSS-VALIDATION
--------------------------------------------
  Train-test split: model learns on 80% data and is tested on the unseen 20%.
  K-fold cross-validation (k = 5):
    1. Divide data into 5 equal folds.
    2. Train on 4 folds, test on the remaining 1.
    3. Repeat 5 times so each fold is the test set once.
    4. Average the 5 scores -> more reliable than a single split.

ADVANTAGES AND DISADVANTAGES
----------------------------
  Advantages: very simple, no training time, works for multi-class,
              naturally handles non-linear boundaries.
  Disadvantages: slow prediction for big data (distance to every point),
                 needs feature scaling, sensitive to irrelevant features and noise,
                 performs badly in very high dimensions (curse of dimensionality).

APPLICATIONS
------------
  Recommendation systems, pattern recognition, handwriting recognition,
  medical diagnosis.

POSSIBLE VIVA QUESTIONS
-----------------------
Q1: Why is K-NN called a lazy learner?
A:  K-NN does not build any model or learn parameters during training; it
    simply stores the training data. All the work (computing distances and
    voting) happens at prediction time. That is why training is instant but
    prediction can be slow for large datasets.

Q2: How do you choose the value of K?
A:  A small K (like 1) is sensitive to noise and overfits, while a large K
    smooths too much and underfits. The best K is found by trying several
    values and choosing the one with the best cross-validation score. For
    two classes, an odd K is preferred to avoid ties in voting.

Q3: Which distance measures are used in K-NN?
A:  The most common is Euclidean distance, sqrt(sum (xi - yi)^2), which is
    the straight-line distance. Manhattan distance, sum |xi - yi|, adds up
    absolute differences like walking on city blocks. Both are special cases
    of Minkowski distance with p = 2 and p = 1 respectively.

Q4: Why is feature scaling important for K-NN?
A:  K-NN decides neighbours by distance. If one feature has large values
    (like area in thousands) and another has small values (like smoothness
    around 0.1), the large feature will dominate the distance and the small
    one will be ignored. Scaling puts all features on the same scale so each
    contributes fairly.

Q5: What is the curse of dimensionality?
A:  When the number of features becomes very large, all points start to look
    almost equally far from each other, so the idea of a "nearest" neighbour
    loses meaning. K-NN then performs poorly. Feature selection or
    dimensionality reduction (like PCA) helps.

Q6: Can K-NN be used for regression?
A:  Yes. Instead of a majority vote, K-NN regression predicts the average (or
    distance-weighted average) of the output values of the K nearest
    neighbours. In sklearn this is done with KNeighborsRegressor.
'''
