# Practical 9: Decision Tree Classification
# Dataset: Breast Cancer Wisconsin (UCI Machine Learning Repository)
# Goal: Predict whether a tumour is malignant (0) or benign (1)

import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import confusion_matrix, accuracy_score, recall_score, f1_score, roc_auc_score

# Step 1: Load the dataset
data = load_breast_cancer()
X = data.data
y = data.target

# Step 2: Split into training set (80%) and test set (20%)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 3: Create and train the model
# criterion = "gini" (can also use "entropy"), max_depth limits the tree size
model = DecisionTreeClassifier(criterion="gini", max_depth=4, random_state=42)
model.fit(X_train, y_train)

# Step 4: Predict on the test set
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]

# Step 5: Calculate evaluation metrics
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
accuracy = accuracy_score(y_test, y_pred)
error = 1 - accuracy
recall = recall_score(y_test, y_pred)
specificity = tn / (tn + fp)
f1 = f1_score(y_test, y_pred)
auc = roc_auc_score(y_test, y_prob)

print("===== Decision Tree Classifier =====")
print("True Positive  (TP):", tp)
print("True Negative  (TN):", tn)
print("False Positive (FP):", fp)
print("False Negative (FN):", fn)
print("Accuracy    :", round(accuracy, 4))
print("Error       :", round(error, 4))
print("Recall      :", round(recall, 4))
print("Specificity :", round(specificity, 4))
print("F1-score    :", round(f1, 4))
print("AUC         :", round(auc, 4))

# Step 6: K-fold cross-validation (k = 5)
scores = cross_val_score(model, X, y, cv=5, scoring="accuracy")
print("\n5-Fold Cross-Validation Accuracy:", scores.round(4))
print("Mean CV Accuracy:", round(scores.mean(), 4))

# Step 7: Draw the tree
plt.figure(figsize=(16, 8))
plot_tree(model, feature_names=data.feature_names, class_names=data.target_names,
          filled=True, fontsize=7)
plt.title("Decision Tree")
plt.show()


# =====================================================================
#                    THEORY AND EXPLANATION
# =====================================================================
'''
1. WHAT IS A DECISION TREE?
---------------------------
A Decision Tree is a flowchart-like model that makes decisions by asking
a series of YES/NO questions about the features.

  ROOT NODE     -> the first question (best feature to split on)
  INTERNAL NODE -> further questions
  BRANCH        -> answer to a question (yes / no)
  LEAF NODE     -> final decision (class label)

  Example:  Is worst radius <= 16.8?
              Yes -> Is worst concave points <= 0.13? -> ... -> Benign
              No  -> ... -> Malignant

2. HOW DOES IT CHOOSE THE BEST QUESTION (SPLIT)?
------------------------------------------------
It chooses the feature and value that make the child nodes as PURE as
possible (a pure node has only one class). Impurity is measured by:

  GINI INDEX (used here, criterion="gini"):
      Gini = 1 - sum of (pi^2)
      pi = proportion of class i in the node
      Gini = 0 -> pure node; maximum 0.5 for two equal classes.

  ENTROPY (criterion="entropy"):
      Entropy = - sum of ( pi * log2(pi) )
      Entropy = 0 -> pure node; 1 -> 50/50 for two classes.

  INFORMATION GAIN:
      Information Gain = Entropy(parent) - weighted average Entropy(children)
      The split with the HIGHEST information gain is chosen.

  Algorithms: ID3 (uses entropy), C4.5 (gain ratio), CART (uses Gini, used by sklearn).

3. OVERFITTING AND PRUNING
--------------------------
A tree grown fully will memorise the training data (overfitting).
We control it by:
  max_depth          -> maximum number of levels (here 4)
  min_samples_split  -> minimum samples needed to split a node
  min_samples_leaf   -> minimum samples in a leaf
This limiting is called PRUNING (pre-pruning). Post-pruning removes
branches after the full tree is grown.

4. HOW THE PROGRAM WORKS
------------------------
  a) Load Breast Cancer dataset, split 80/20.
  b) DecisionTreeClassifier(criterion="gini", max_depth=4).
     Decision trees do NOT need feature scaling, because they only
     compare a feature with a threshold.
  c) Predict class and probability (probability = fraction of class 1
     in the leaf node), compute all metrics.
  d) 5-fold cross-validation.
  e) plot_tree() draws the tree. Each box shows the question, Gini value,
     number of samples, and the class.


CONFUSION MATRIX
----------------
                       Predicted Positive   Predicted Negative
  Actual Positive            TP                   FN
  Actual Negative            FP                   TN

  TP (True Positive)  : actually positive, predicted positive  (correct)
  TN (True Negative)  : actually negative, predicted negative  (correct)
  FP (False Positive) : actually negative, predicted positive  (Type I error)
  FN (False Negative) : actually positive, predicted negative  (Type II error)
  sklearn's confusion_matrix(...).ravel() returns  tn, fp, fn, tp  (in this order).

EVALUATION METRICS AND FORMULAS
-------------------------------
  Accuracy    = (TP + TN) / (TP + TN + FP + FN)   -> fraction of correct predictions
  Error       = 1 - Accuracy = (FP + FN) / Total  -> fraction of wrong predictions
  Recall      = TP / (TP + FN)   (Sensitivity / True Positive Rate)
                -> out of all actual positives, how many we caught
  Specificity = TN / (TN + FP)   (True Negative Rate)
                -> out of all actual negatives, how many we correctly rejected
  Precision   = TP / (TP + FP)   -> out of predicted positives, how many are correct
  F1-score    = 2 * Precision * Recall / (Precision + Recall)
                -> balance of precision and recall (harmonic mean)
  AUC         = Area Under the ROC curve. ROC plots Recall (TPR) against
                False Positive Rate (1 - Specificity) at all thresholds.
                1.0 = perfect, 0.5 = random guessing.

TRAIN-TEST SPLIT AND K-FOLD CROSS-VALIDATION
--------------------------------------------
  Train-test split: model learns on 80% data and is tested on the unseen 20%.
  K-fold cross-validation (k = 5):
    1. Divide data into 5 equal folds.
    2. Train on 4 folds, test on the remaining 1.
    3. Repeat 5 times so each fold is the test set once.
    4. Average the 5 scores -> more reliable than a single split.

ADVANTAGES AND DISADVANTAGES
----------------------------
  Advantages: very easy to understand and visualise, no scaling needed,
              handles numerical and categorical data, shows feature importance.
  Disadvantages: overfits easily, unstable (small data change -> different tree),
                 greedy splitting may not give the best overall tree.
  Random Forest (many trees voting together) fixes most of these problems.

APPLICATIONS
------------
  Loan approval, medical diagnosis, customer segmentation, fraud detection.

POSSIBLE VIVA QUESTIONS
-----------------------
Q1: What is the Gini index?
A:  Gini index measures the impurity of a node: Gini = 1 - sum(pi^2), where
    pi is the proportion of class i. It is 0 when all samples in the node
    belong to one class (pure) and maximum (0.5 for two classes) when the
    classes are equally mixed. The tree picks the split that reduces Gini
    the most.

Q2: What is entropy and information gain?
A:  Entropy measures disorder: Entropy = -sum(pi * log2 pi); it is 0 for a
    pure node and 1 for a 50-50 split of two classes. Information gain is
    entropy of the parent minus the weighted entropy of the children after
    a split. The split with the highest information gain is chosen.

Q3: What is the difference between Gini and entropy?
A:  Both measure impurity and usually give very similar trees. Gini is
    slightly faster because it does not use logarithms, so it is the
    default in sklearn (CART algorithm). Entropy is used in ID3 and C4.5
    algorithms.

Q4: Why do decision trees overfit and how do we prevent it?
A:  If a tree keeps splitting until every leaf is pure, it memorises the
    training data including noise, which gives poor test results. We prevent
    this by pruning: limiting max_depth, setting min_samples_split or
    min_samples_leaf (pre-pruning), or removing weak branches after the tree
    is built (post-pruning).

Q5: Does a decision tree need feature scaling?
A:  No. A decision tree only compares a feature with a threshold value
    (e.g. radius <= 16.8), so the scale of the feature does not change which
    side a point falls on. That is why we did not use StandardScaler in this
    program.

Q6: What is a Random Forest?
A:  A Random Forest is a collection of many decision trees, each trained on a
    random sample of the data and a random subset of features. The final
    prediction is the majority vote of all trees. It is much more accurate
    and stable than a single tree and overfits less.
'''
