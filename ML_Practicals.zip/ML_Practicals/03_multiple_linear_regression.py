# Practical 3: Multiple Linear Regression
# Dataset: Diabetes dataset (from sklearn, originally from Efron et al.)
# Goal: Predict disease progression using ALL 10 features

from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Step 1: Load the dataset
data = load_diabetes()
X = data.data      # all 10 features
y = data.target

# Step 2: Split into training set (80%) and test set (20%)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 3: Create and train the model
model = LinearRegression()
model.fit(X_train, y_train)

# Step 4: Predict on the test set
y_pred = model.predict(X_test)

# Step 5: Evaluation
print("===== Multiple Linear Regression =====")
print("Coefficients:")
for name, coef in zip(data.feature_names, model.coef_):
    print("  ", name, ":", round(coef, 4))
print("Intercept :", round(model.intercept_, 4))
print("MSE       :", round(mean_squared_error(y_test, y_pred), 4))
print("R2 Score  :", round(r2_score(y_test, y_pred), 4))

# Step 6: K-fold cross-validation (k = 5)
r2_scores = cross_val_score(model, X, y, cv=5, scoring="r2")
mse_scores = -cross_val_score(model, X, y, cv=5, scoring="neg_mean_squared_error")
print("\n5-Fold CV R2  :", r2_scores.round(4), " Mean:", round(r2_scores.mean(), 4))
print("5-Fold CV MSE :", mse_scores.round(2), " Mean:", round(mse_scores.mean(), 4))


# =====================================================================
#                    THEORY AND EXPLANATION
# =====================================================================
'''
1. WHAT IS MULTIPLE LINEAR REGRESSION?
--------------------------------------
It is an extension of simple linear regression where the output y
depends on TWO OR MORE input features.

  Equation:  y = b0 + b1*x1 + b2*x2 + ... + bn*xn

  y        = output (disease progression)
  x1...xn  = input features (age, sex, bmi, bp, s1 ... s6) -> 10 features
  b0       = intercept
  b1...bn  = coefficients (weights) of each feature

  Each coefficient bi tells: how much y changes when xi increases by 1,
  KEEPING ALL OTHER FEATURES CONSTANT.

2. MATRIX FORM AND THE NORMAL EQUATION
--------------------------------------
  Y = X * B

  Y = column of outputs (n x 1)
  X = matrix of inputs with a column of 1s added for the intercept (n x (p+1))
  B = column of coefficients ((p+1) x 1)

  Best coefficients (Ordinary Least Squares, minimising squared error):

        B = (X^T * X)^(-1) * X^T * Y           <- Normal Equation

  X^T = transpose of X,  ^(-1) = matrix inverse.
  sklearn's LinearRegression solves this for us.

3. ASSUMPTIONS
--------------
  - Linear relationship between features and output
  - No (or little) MULTICOLLINEARITY: features should not be highly
    correlated with each other
  - Errors are independent, have constant variance, and are normal

  Multicollinearity makes coefficients unstable. Ridge and Lasso
  regression (program 5) help with this problem.

4. HOW THE PROGRAM WORKS
------------------------
  a) Load the Diabetes dataset with ALL 10 features.
     (The features are already scaled by the dataset creators.)
  b) Split 80% training, 20% testing.
  c) model.fit() finds the intercept and 10 coefficients.
  d) We print each feature name with its coefficient.
     A big positive coefficient -> that feature increases disease progression.
     A negative coefficient     -> that feature decreases it.
  e) Predict on test set, calculate MSE and R2.
  f) 5-fold cross-validation.

5. EVALUATION METRICS AND FORMULAS
----------------------------------
  MSE = (1/n) * sum of (yi - yi_pred)^2         -> lower is better

  R2  = 1 - [ sum of (yi - yi_pred)^2 / sum of (yi - y_mean)^2 ]
        -> fraction of variance explained, closer to 1 is better

  Adjusted R2 (useful when there are many features):
                       (1 - R2) * (n - 1)
    Adjusted R2 = 1 - --------------------
                          (n - p - 1)
    n = number of samples, p = number of features.
    Normal R2 always increases when you add features (even useless ones);
    Adjusted R2 increases only if the new feature really helps.

  Result: R2 is about 0.45 - 0.48, much better than simple linear
  regression (about 0.23 - 0.32), because more information is used.

6. TRAIN-TEST SPLIT AND K-FOLD CROSS-VALIDATION
-----------------------------------------------
  Train-test split: learn on 80%, test on unseen 20%.
  K-fold (k = 5): 5 rounds, each fold is the test set once, average result.

7. ADVANTAGES AND DISADVANTAGES
-------------------------------
  Advantages: uses many features, easy to interpret, fast.
  Disadvantages: assumes linear relation, affected by multicollinearity
                 and outliers, can overfit with too many features.

8. APPLICATIONS
---------------
  House price (area, rooms, location), sales prediction,
  crop yield (rainfall, temperature, fertiliser).

9. POSSIBLE VIVA QUESTIONS
--------------------------
Q1: What is multicollinearity and why is it a problem?
A:  Multicollinearity means two or more input features are highly correlated
    with each other (for example, height in cm and height in inches). The
    model cannot decide how to divide the effect between them, so the
    coefficients become unstable and can even have the wrong sign. It can be
    detected with a correlation matrix or VIF, and handled by removing
    features or by using Ridge/Lasso regression.

Q2: What is the normal equation?
A:  The normal equation B = (X^T X)^(-1) X^T Y is a direct formula that gives
    the best coefficients for linear regression in one step, without any
    iterations. It works well for small and medium data. For very large
    data, computing the matrix inverse is slow, so gradient descent is used
    instead.

Q3: How do you interpret a coefficient in multiple regression?
A:  Each coefficient shows how much the output changes when that feature
    increases by one unit, while all other features are kept constant. A
    positive coefficient increases the prediction and a negative one
    decreases it. In our output, bmi and s5 have large positive coefficients,
    so they have a strong effect on disease progression.

Q4: What is adjusted R2 and why is it needed?
A:  Normal R2 always increases (or stays the same) when we add more features,
    even useless ones, which can be misleading. Adjusted R2 includes a
    penalty for the number of features, so it increases only when a new
    feature actually improves the model. It is better for comparing models
    with different numbers of features.

Q5: Why did multiple regression give a better R2 than simple regression?
A:  Simple regression used only BMI, which explains only a small part of
    disease progression. Multiple regression uses all 10 features, such as
    blood pressure and blood serum values, which carry extra information. So
    it explains more of the variation, and R2 rose from about 0.32 to 0.48.

Q6: What is overfitting in regression?
A:  Overfitting happens when a model learns the noise of the training data
    instead of the real pattern. It gives very low error on training data but
    high error on test data. It is more likely with many features and few
    samples, and is reduced using cross-validation, feature selection or
    regularization.
'''
