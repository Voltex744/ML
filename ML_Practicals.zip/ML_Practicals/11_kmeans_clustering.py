# Practical 11: K-Means Clustering
# Dataset: Iris (UCI Machine Learning Repository)
# Goal: Group flowers into 3 clusters WITHOUT using the labels
# Clustering is unsupervised, so instead of accuracy we use:
#   - Silhouette score (how well separated the clusters are, -1 to 1, higher is better)
#   - Adjusted Rand Index (how close clusters are to the true species, 0 to 1)

import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, adjusted_rand_score

# Step 1: Load the dataset
data = load_iris()
X = StandardScaler().fit_transform(data.data)   # scale features
y_true = data.target                            # used ONLY to check results

# Step 2: Elbow method - find a good number of clusters
inertia = []
for k in range(1, 11):
    km = KMeans(n_clusters=k, n_init=10, random_state=42)
    km.fit(X)
    inertia.append(km.inertia_)

plt.plot(range(1, 11), inertia, marker="o")
plt.xlabel("Number of clusters (k)")
plt.ylabel("Inertia (within-cluster sum of squares)")
plt.title("Elbow Method")
plt.show()

# Step 3: Train K-Means with k = 3
model = KMeans(n_clusters=3, n_init=10, random_state=42)
labels = model.fit_predict(X)

# Step 4: Evaluation
print("===== K-Means Clustering (k = 3) =====")
print("Inertia             :", round(model.inertia_, 4))
print("Silhouette Score    :", round(silhouette_score(X, labels), 4))
print("Adjusted Rand Index :", round(adjusted_rand_score(y_true, labels), 4))
print("Points in each cluster:", [list(labels).count(i) for i in range(3)])

# Step 5: Plot the clusters (first two features)
plt.scatter(X[:, 0], X[:, 1], c=labels, cmap="viridis")
centers = model.cluster_centers_
plt.scatter(centers[:, 0], centers[:, 1], c="red", marker="X", s=200, label="Centroids")
plt.xlabel("Sepal length (scaled)")
plt.ylabel("Sepal width (scaled)")
plt.title("K-Means Clusters")
plt.legend()
plt.show()


# =====================================================================
#                    THEORY AND EXPLANATION
# =====================================================================
'''
1. WHAT IS CLUSTERING?
----------------------
Clustering is UNSUPERVISED learning: the data has NO labels. The
algorithm groups similar data points together into CLUSTERS by itself.
Points in the same cluster are similar; points in different clusters
are different.

2. WHAT IS K-MEANS?
-------------------
K-Means divides the data into K clusters. Each cluster has a CENTRE
called a CENTROID (the mean of all points in the cluster). Every point
belongs to the cluster with the nearest centroid.

3. ALGORITHM STEPS
------------------
  1. Choose K (number of clusters).
  2. Randomly pick K points as the starting centroids.
  3. ASSIGNMENT step: assign every point to its nearest centroid
     (using Euclidean distance):
        d = sqrt( (x1 - c1)^2 + (x2 - c2)^2 + ... )
  4. UPDATE step: recalculate each centroid as the mean of its points:
        new centroid = (sum of points in cluster) / (number of points)
  5. Repeat steps 3 and 4 until the centroids stop changing (convergence).

  n_init=10 -> the algorithm runs 10 times with different starting
  centroids and keeps the best result (because a bad start can give
  bad clusters). sklearn uses the smart "k-means++" initialisation.

4. OBJECTIVE FUNCTION (INERTIA / WCSS)
--------------------------------------
K-Means minimises the Within-Cluster Sum of Squares:

  WCSS (Inertia) = sum over all clusters of
                   sum over points in that cluster of ||x - centroid||^2

  Lower inertia = points are closer to their centroids = tighter clusters.

5. CHOOSING K: ELBOW METHOD
---------------------------
  Run K-Means for K = 1, 2, ..., 10 and plot inertia against K.
  Inertia always decreases as K increases, but after some point the
  decrease becomes small. The point where the curve bends like an
  "ELBOW" is a good choice of K. For Iris, the elbow is around K = 3
  (and Iris really has 3 species).

6. EVALUATION METRICS FOR CLUSTERING
------------------------------------
Accuracy, confusion matrix, train-test split and cross-validation are
for SUPERVISED models (which have correct answers). Clustering has no
labels, so we use different measures:

  SILHOUETTE SCORE (no labels needed):
    For each point:
      a = average distance to other points in its OWN cluster
      b = average distance to points in the NEAREST OTHER cluster
                       b - a
      s  =  -----------------
              max(a, b)
    Final score = average s over all points. Range -1 to +1.
      close to +1 -> well separated clusters
      close to 0  -> overlapping clusters
      negative    -> points are probably in the wrong cluster

  ADJUSTED RAND INDEX (ARI) (needs true labels, used only for checking):
    Measures how similar the clusters are to the real classes.
    1 = perfect match, 0 = random grouping.
    Iris has true species labels, so we can use ARI to check our clusters.

7. HOW THE PROGRAM WORKS
------------------------
  a) Load Iris dataset (150 flowers, 4 features, 3 species).
     Labels are NOT given to K-Means; they are kept only to calculate ARI.
  b) StandardScaler makes all features the same scale (K-Means uses distance).
  c) Elbow method: run K-Means for K = 1 to 10 and plot inertia.
  d) Train K-Means with K = 3, get the cluster label of each flower.
  e) Print inertia, silhouette score, ARI and cluster sizes.
  f) Plot clusters on first two features with centroids marked by a red X.

8. ADVANTAGES AND DISADVANTAGES
-------------------------------
  Advantages: simple, fast, works well on large data, easy to understand.
  Disadvantages: K must be chosen in advance, sensitive to starting points
                 and outliers, assumes round (spherical) clusters of similar
                 size, needs feature scaling.

9. APPLICATIONS
---------------
  Customer segmentation, image compression, document grouping,
  market research, anomaly detection.

10. POSSIBLE VIVA QUESTIONS
--------------------------
Q1: Is K-Means supervised or unsupervised? Why?
A:  K-Means is unsupervised, because it does not use any labels. It groups
    data only on the basis of similarity (distance) between points. In our
    program the Iris labels are used only afterwards to check the result with
    ARI, not for training.

Q2: What is a centroid?
A:  A centroid is the centre of a cluster, calculated as the mean of all the
    points in that cluster. Every data point is assigned to the cluster whose
    centroid is nearest. After every iteration, centroids are recalculated
    until they stop moving.

Q3: How do you choose the value of K?
A:  The elbow method plots inertia (WCSS) against different values of K and
    picks the point where the decrease suddenly slows down, forming an
    "elbow". The silhouette method picks the K with the highest silhouette
    score. Domain knowledge also helps - Iris has 3 species, so K = 3.

Q4: What is inertia (WCSS)?
A:  Inertia, or Within-Cluster Sum of Squares, is the sum of squared
    distances of every point from its cluster centroid. Lower inertia means
    tighter clusters. K-Means tries to minimise it, but it always decreases
    when K increases, so it cannot be used alone to choose K.

Q5: Why do we use n_init and k-means++?
A:  K-Means starts with random centroids, and a bad start can lead to poor
    clusters (a local minimum). k-means++ chooses starting centroids that are
    spread far apart, which gives better results. n_init=10 runs the whole
    algorithm 10 times and keeps the result with the lowest inertia.

Q6: What is the silhouette score?
A:  It measures how well each point fits in its own cluster compared to the
    nearest other cluster, using s = (b - a) / max(a, b). It ranges from -1
    to +1; values near +1 mean well-separated clusters, near 0 mean
    overlapping clusters, and negative values mean points may be in the wrong
    cluster.

Q7: What are the limitations of K-Means?
A:  K must be chosen beforehand, results depend on the starting centroids,
    and outliers can pull centroids away. It also assumes clusters are round
    and of similar size, so it fails on long or irregular-shaped clusters,
    where algorithms like DBSCAN work better.
'''
