MACHINE LEARNING PRACTICALS - 12 PROGRAMS (Python)
===================================================

Install the required libraries once:
    pip install scikit-learn matplotlib scipy numpy

Run any program like this:
    python 01_naive_bayes_classifier.py

The datasets come built into scikit-learn, so no download or internet is needed:
  - Breast Cancer Wisconsin (UCI)  -> classification programs 1, 6, 7, 8, 9, 10
  - Diabetes                       -> regression programs 2, 3, 4, 5
  - Iris (UCI)                     -> clustering programs 11, 12

Every program follows the same steps:
  1. Load dataset
  2. Split into training (80%) and test (20%) sets
  3. Train the model
  4. Predict on the test set
  5. Report efficacy
  6. 5-fold cross-validation

Efficacy reported:
  Regression     -> MSE, R2 score
  Classification -> TP, TN, FP, FN, Accuracy, Error, Recall, Specificity, F1-score, AUC
  Clustering     -> Silhouette score, Adjusted Rand Index (clustering has no labels,
                    so a train/test split and accuracy do not apply)

Formulas:
  Accuracy    = (TP + TN) / (TP + TN + FP + FN)
  Error       = 1 - Accuracy
  Recall      = TP / (TP + FN)
  Specificity = TN / (TN + FP)
  Precision   = TP / (TP + FP)
  F1-score    = 2 * Precision * Recall / (Precision + Recall)
  MSE         = average of (actual - predicted)^2
  R2          = 1 - (sum of squared errors / total sum of squares)
