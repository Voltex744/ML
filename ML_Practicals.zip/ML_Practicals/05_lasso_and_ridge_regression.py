# Practical 5: Lasso and Ridge Regression
# Dataset: Diabetes dataset (from sklearn, originally from Efron et al.)
# Goal: Compare Ridge (L2 penalty) and Lasso (L1 penalty) regression

from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import Ridge, Lasso
from sklearn.metrics import mean_squared_error, r2_score

# Step 1: Load the dataset
data = load_diabetes()
X = data.data
y = data.target

# Step 2: Split into training set (80%) and test set (20%)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 3: Create both models (alpha = strength of penalty)
models = {
    "Ridge Regression": Ridge(alpha=1.0),
    "Lasso Regression": Lasso(alpha=0.1),
}

# Step 4: Train, predict and evaluate each model
for name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    print("=====", name, "=====")
    print("Coefficients :", model.coef_.round(2))
    print("MSE          :", round(mean_squared_error(y_test, y_pred), 4))
    print("R2 Score     :", round(r2_score(y_test, y_pred), 4))

    # K-fold cross-validation (k = 5)
    r2_scores = cross_val_score(model, X, y, cv=5, scoring="r2")
    mse_scores = -cross_val_score(model, X, y, cv=5, scoring="neg_mean_squared_error")
    print("5-Fold CV R2  :", r2_scores.round(4), " Mean:", round(r2_scores.mean(), 4))
    print("5-Fold CV MSE :", mse_scores.round(2), " Mean:", round(mse_scores.mean(), 4))
    print()

# Note: Lasso can make some coefficients exactly 0 (feature selection),
# while Ridge only makes them small.


# =====================================================================
#                    THEORY AND EXPLANATION
# =====================================================================
'''
1. WHY DO WE NEED RIDGE AND LASSO?
----------------------------------
Normal linear regression can OVERFIT when there are many features or
when features are correlated (multicollinearity). The coefficients can
become very large and unstable.

REGULARIZATION solves this by adding a PENALTY on large coefficients to
the cost function. This forces the model to keep coefficients small,
making it simpler and better on new data.

2. COST FUNCTIONS
-----------------
  Normal Linear Regression:
    Cost = sum of (yi - yi_pred)^2

  RIDGE Regression (L2 regularization):
    Cost = sum of (yi - yi_pred)^2  +  alpha * sum of (bj^2)

  LASSO Regression (L1 regularization):
    Cost = sum of (yi - yi_pred)^2  +  alpha * sum of |bj|

  bj    = coefficients (the intercept is not penalised)
  alpha = (also called lambda) regularization strength
          alpha = 0      -> same as normal linear regression
          alpha small    -> small penalty
          alpha large    -> big penalty, coefficients pushed close to 0
                            (too large -> underfitting)

  LASSO = Least Absolute Shrinkage and Selection Operator.

3. DIFFERENCE BETWEEN RIDGE AND LASSO
-------------------------------------
  | Ridge (L2)                          | Lasso (L1)                          |
  |-------------------------------------|-------------------------------------|
  | Penalty = alpha * sum(b^2)          | Penalty = alpha * sum(|b|)          |
  | Shrinks coefficients towards 0      | Can make coefficients EXACTLY 0     |
  | Never removes a feature             | Does FEATURE SELECTION              |
  | Good when all features are useful   | Good when only a few are important  |
  | Handles multicollinearity well      | Picks one of the correlated features|

  Elastic Net = combination of both L1 and L2 penalties.

  In the output of this program, look at the Lasso coefficients:
  some of them are 0. Those features were removed by Lasso.

4. HOW THE PROGRAM WORKS
------------------------
  a) Load Diabetes dataset with all 10 features.
  b) Split 80% training, 20% testing.
  c) Create two models in a dictionary:
       Ridge(alpha=1.0) and Lasso(alpha=0.1)
  d) A for-loop trains, predicts and evaluates both models one by one,
     so we do not repeat the code.
  e) For each model print coefficients, MSE, R2, and 5-fold CV results.

  Note: regularization works best when features are on the same scale.
  The Diabetes features are already scaled. For other datasets, use
  StandardScaler before Ridge/Lasso.

5. EVALUATION METRICS AND FORMULAS
----------------------------------
  MSE = (1/n) * sum of (yi - yi_pred)^2               -> lower is better
  R2  = 1 - [ sum (yi - yi_pred)^2 / sum (yi - y_mean)^2 ]  -> closer to 1 is better

6. TRAIN-TEST SPLIT AND K-FOLD CROSS-VALIDATION
-----------------------------------------------
  Cross-validation is used to choose the best alpha. sklearn even has
  RidgeCV and LassoCV which try many alpha values automatically.

7. ADVANTAGES AND DISADVANTAGES
-------------------------------
  Ridge: + reduces overfitting, + handles multicollinearity,
         - keeps all features (no selection)
  Lasso: + reduces overfitting, + automatic feature selection,
         - with correlated features, picks one randomly and drops others

8. POSSIBLE VIVA QUESTIONS
--------------------------
Q1: What is regularization?
A:  Regularization is a technique to reduce overfitting by adding a penalty
    on the size of the coefficients to the cost function. Because large
    coefficients now increase the cost, the model prefers smaller, simpler
    coefficients. This makes the model less sensitive to noise and better on
    new data.

Q2: What is the difference between L1 and L2 regularization?
A:  L1 (Lasso) adds alpha * sum of |b|, while L2 (Ridge) adds
    alpha * sum of b^2. L1 can push some coefficients exactly to zero, so it
    removes features. L2 only shrinks coefficients towards zero but never
    makes them exactly zero, so all features are kept.

Q3: Which one performs feature selection and why?
A:  Lasso performs feature selection. Because of the shape of the absolute
    value penalty, the best solution often lies at a point where some
    coefficients are exactly 0. In our output, a few Lasso coefficients are
    0, meaning those features were dropped from the model.

Q4: What is the role of alpha?
A:  Alpha controls the strength of the penalty. When alpha = 0, Ridge and
    Lasso become ordinary linear regression. As alpha increases,
    coefficients become smaller; if alpha is too large, the model becomes too
    simple and underfits. The best alpha is chosen using cross-validation
    (for example with RidgeCV or LassoCV).

Q5: When should you use Ridge and when Lasso?
A:  Use Ridge when you believe most features are useful and when features
    are correlated, because it spreads the weight among them. Use Lasso when
    you suspect only a few features are important and you want a simpler,
    more interpretable model. Elastic Net combines both when you need a mix.

Q6: Why should features be scaled before regularization?
A:  The penalty treats all coefficients equally. If features are on very
    different scales, their coefficients will also be on different scales,
    so some features would be penalised much more than others unfairly.
    Scaling with StandardScaler puts all features on the same scale so the
    penalty is fair.
'''
