# Practical 2: Simple Linear Regression
# Dataset: Diabetes dataset (from sklearn, originally from Efron et al.)
# Goal: Predict disease progression using ONE feature only (BMI)

import matplotlib.pyplot as plt
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Step 1: Load the dataset
data = load_diabetes()
X = data.data[:, [2]]   # only one feature: BMI (column 2)
y = data.target

# Step 2: Split into training set (80%) and test set (20%)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 3: Create and train the model
model = LinearRegression()
model.fit(X_train, y_train)

# Step 4: Predict on the test set
y_pred = model.predict(X_test)

# Step 5: Evaluation
print("===== Simple Linear Regression =====")
print("Slope (m)     :", round(model.coef_[0], 4))
print("Intercept (c) :", round(model.intercept_, 4))
print("MSE           :", round(mean_squared_error(y_test, y_pred), 4))
print("R2 Score      :", round(r2_score(y_test, y_pred), 4))

# Step 6: K-fold cross-validation (k = 5)
r2_scores = cross_val_score(model, X, y, cv=5, scoring="r2")
mse_scores = -cross_val_score(model, X, y, cv=5, scoring="neg_mean_squared_error")
print("\n5-Fold CV R2  :", r2_scores.round(4), " Mean:", round(r2_scores.mean(), 4))
print("5-Fold CV MSE :", mse_scores.round(2), " Mean:", round(mse_scores.mean(), 4))

# Step 7: Plot the regression line
plt.scatter(X_test, y_test, color="blue", label="Actual")
plt.plot(X_test, y_pred, color="red", label="Predicted line")
plt.xlabel("BMI")
plt.ylabel("Disease progression")
plt.title("Simple Linear Regression")
plt.legend()
plt.show()


# =====================================================================
#                    THEORY AND EXPLANATION
# =====================================================================
'''
1. WHAT IS REGRESSION?
----------------------
Regression is used to predict a CONTINUOUS number (like price, marks,
temperature), unlike classification which predicts a category.

2. WHAT IS SIMPLE LINEAR REGRESSION?
------------------------------------
It finds a STRAIGHT LINE relationship between ONE input variable (x)
and ONE output variable (y).

  Equation:   y = m * x + c        (also written y = b0 + b1 * x)

  y = dependent variable (output we want to predict) -> disease progression
  x = independent variable (input)                   -> BMI
  m (b1) = slope       -> how much y changes when x increases by 1
  c (b0) = intercept   -> value of y when x = 0

3. HOW ARE m AND c FOUND? (Ordinary Least Squares, OLS)
--------------------------------------------------------
The best line is the one that makes the total SQUARED ERROR smallest.
  Error for one point (residual) = actual y - predicted y

  Minimise:  SSE = sum of (yi - (m*xi + c))^2

Solving gives the formulas:

        sum of (xi - x_mean) * (yi - y_mean)
  m  =  ------------------------------------
             sum of (xi - x_mean)^2

  c  =  y_mean - m * x_mean

We square the errors so that positive and negative errors do not cancel
out, and so that bigger errors are punished more.

4. ASSUMPTIONS OF LINEAR REGRESSION
-----------------------------------
  - Linearity: relation between x and y is a straight line
  - Independence: observations do not depend on each other
  - Homoscedasticity: errors have constant variance
  - Normality: errors are normally distributed

5. HOW THE PROGRAM WORKS
------------------------
  a) Load the Diabetes dataset (442 patients). We take only ONE feature,
     BMI (column 2), because simple linear regression has only one input.
     X = data.data[:, [2]] keeps it as a 2D array (sklearn needs 2D input).
  b) Split 80% training, 20% testing.
  c) model.fit() calculates slope (coef_) and intercept (intercept_).
  d) model.predict() gives predicted values for the test set.
  e) Calculate MSE and R2.
  f) 5-fold cross-validation for R2 and MSE.
     sklearn gives "neg_mean_squared_error" (negative, because sklearn
     always treats higher as better), so we put a minus sign to make it positive.
  g) Plot actual points (blue) and the fitted line (red).

6. EVALUATION METRICS AND FORMULAS
----------------------------------
  MSE (Mean Squared Error):
               1
    MSE  =  ------ * sum of (yi - yi_pred)^2
               n
    -> average of squared errors. Lower is better. 0 = perfect.

  RMSE = sqrt(MSE)  -> error in the same unit as y.

  R2 Score (Coefficient of Determination):
                 SS_res          sum of (yi - yi_pred)^2
    R2  = 1 -  --------  = 1 -  ------------------------
                 SS_tot          sum of (yi - y_mean)^2

    -> tells what fraction of the variation in y is explained by the model.
    -> R2 = 1   : perfect fit
       R2 = 0   : model is no better than just predicting the mean
       R2 < 0   : model is worse than predicting the mean

  Our R2 is about 0.23 - 0.32, which means BMI alone explains only about
  a quarter to a third of disease progression. That is why we use more
  features in Multiple Linear Regression (program 3).

7. TRAIN-TEST SPLIT AND K-FOLD CROSS-VALIDATION
-----------------------------------------------
  Train-test split: train on 80%, test on unseen 20%.
  K-fold (k = 5): split data into 5 parts, train on 4 and test on 1,
  repeat 5 times, take the average. More reliable than one split.

8. ADVANTAGES AND DISADVANTAGES
-------------------------------
  Advantages: very simple, fast, easy to interpret (slope has meaning).
  Disadvantages: only one feature, only straight-line relations,
                 sensitive to outliers.

9. APPLICATIONS
---------------
  Predicting salary from experience, house price from area,
  sales from advertising budget.

10. POSSIBLE VIVA QUESTIONS
--------------------------
Q1: What is the difference between simple and multiple linear regression?
A:  Simple linear regression uses only one input feature to predict the
    output, so the model is a straight line y = mx + c. Multiple linear
    regression uses two or more input features, y = b0 + b1x1 + b2x2 + ...,
    so the model becomes a plane or hyperplane. Multiple regression usually
    gives better predictions because it uses more information.

Q2: What do the slope and intercept mean?
A:  The slope (m) tells how much the output y changes when the input x
    increases by one unit. A positive slope means y increases with x, and a
    negative slope means y decreases. The intercept (c) is the value of y
    when x is 0, i.e. where the line crosses the y-axis.

Q3: What is the least squares method?
A:  It is the method used to find the best-fit line. It chooses the slope and
    intercept that make the sum of squared errors (actual - predicted)^2 as
    small as possible. We square errors so that positive and negative errors
    do not cancel each other and so that large errors are punished more.

Q4: What is a residual?
A:  A residual is the difference between the actual value and the predicted
    value for a data point (residual = y - y_pred). Positive residual means
    the model predicted too low, negative means too high. A good model has
    small residuals that are randomly scattered with no pattern.

Q5: What is MSE and what is R2? Which is better?
A:  MSE is the average of squared errors; it shows how far predictions are
    from actual values, and lower is better, but its value depends on the
    unit of y. R2 tells what fraction of the variation in y is explained by
    the model, between 0 and 1 (higher is better), and it is unit-free. Both
    are used together: MSE for error size, R2 for overall goodness of fit.

Q6: Can R2 be negative?
A:  Yes. On test data, if the model's predictions are worse than simply
    predicting the average value of y for every point, then SS_res becomes
    larger than SS_tot and R2 becomes negative. This means the model is very
    poor or badly overfitted.

Q7: What are the assumptions of linear regression?
A:  The relation between x and y should be linear, observations should be
    independent, the errors should have constant variance
    (homoscedasticity), and the errors should be roughly normally
    distributed. If these are badly violated, the model's predictions and
    coefficients become unreliable.
'''
